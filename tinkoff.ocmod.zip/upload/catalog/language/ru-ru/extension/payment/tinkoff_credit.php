<?php
// Text
$_['text_title']       = 'Тинькофф кредит';

